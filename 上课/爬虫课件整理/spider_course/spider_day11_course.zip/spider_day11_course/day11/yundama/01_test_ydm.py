from ydmapi import get_result

result = get_result('yzm5.jpg')
# result: unxn
print(result)