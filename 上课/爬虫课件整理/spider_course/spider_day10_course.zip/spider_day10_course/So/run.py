from scrapy import cmdline

cmdline.execute('scrapy crawl so'.split())