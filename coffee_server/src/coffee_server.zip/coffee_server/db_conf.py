host = "127.0.0.1"   # localhost
user = "root"
password = "123456"
dbname = "Coffee_System"

# 设备最大间隔时间（秒），超过该时间未收到该设备数据，则判定为故障
machine_max_interval = 300  