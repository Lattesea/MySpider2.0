from django.apps import AppConfig


class ManageConfig(AppConfig):
    name = 'manage'
